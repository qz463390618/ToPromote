<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>智能行情分析系统</title>
    <link rel="stylesheet" href="{{url('css/share.css')}}">
    <link rel="stylesheet" href="{{url('css/test/test_touzi1_s.css')}}">
</head>
<body>
<div id="wrap">
    <div class="pic_1">
        <div class="width_s">
            <a href="javascript:void(0)" class="btn_1 btn">电脑端下载</a>
            <a href="javascript:void(0)" class="btn_2 btn">苹果官方下载</a>
            <a href="javascript:void(0)" class="btn_3 btn">安卓官方下载</a>
        </div>
    </div>
    <div class="pic_2">
        <div class="width_s">
            <a href="javascript:void(0)" class="btn_1 btn">电脑端下载</a>
            <a href="javascript:void(0)" class="btn_2 btn">苹果官方下载</a>
            <a href="javascript:void(0)" class="btn_3 btn">安卓官方下载</a>
        </div>
    </div>
    <div class="pic_3">
        <div class="width_s">
            <a href="javascript:void(0)" class="btn_1 btn">电脑端下载</a>
            <a href="javascript:void(0)" class="btn_2 btn">苹果官方下载</a>
            <a href="javascript:void(0)" class="btn_3 btn">安卓官方下载</a>
        </div>
    </div>
    <div class="copyright">
        <h2 style="margin-bottom: 0;">投资有风险,入市需谨慎</h2>
        <p>&copy; 版权所有：北京中资北方投资顾问有限公司广州分公司 <br> ICP备案号：粤ICP备16126816号-1</p>
    </div>
</div>
</body>
</html>