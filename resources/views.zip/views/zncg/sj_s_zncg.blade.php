<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>人工智能炒股软件</title>
    <link rel="stylesheet" href="{{url('css/share.css')}}">
    <link rel="stylesheet" type="text/css" href="{{url('css/zncg/sj_zncg.css')}}">
    <link rel="stylesheet" href="{{url('css/sj_form.css')}}">
    <script src="{{url('js/jquery.js')}}"></script>
</head>
<body>
<div class="warp">
    <div class="w-font down">
        <img src="http://img.zengwf.com/images/zncg/btn_1.png" alt="">
        <div class="w-img">
            <img src="http://img.zengwf.com/images/zncg/btn_2.png" alt="">
        </div>
    </div>

</div>
<div class="container">
    <div class="c-one">
        <div class="grab">
            <div class="frist"><img src=" http://img.zengwf.com/images/zncg/sg_02 .jpg" alt=""></div>
            <ul>
                <li>
                    <div class="g-img1"><img src="http://img.zengwf.com/images/zncg/02.jpg" alt=""></div>
                </li>
                <li>
                    <div class="g-img2"><img src="http://img.zengwf.com/images/zncg/01.jpg" alt=""></div>
                </li>
            </ul>
        </div>


        <div class="topspeed">
            <img src="http://img.zengwf.com/images/zncg/b-4.jpg" alt="">更简洁的页面/
            <img src="http://img.zengwf.com/images/zncg/b-5.jpg" alt="">更实用的功能/
            <img src="http://img.zengwf.com/images/zncg/b-6.jpg" alt="">更有效的操作
        </div>
        <div class="t-q down">极速下载</div>
    </div>
    <div class="c-two">
        <div class="o-img">
            <img src="http://img.zengwf.com/images/zncg/z-2.jpg" alt="">
        </div>
        <div class="storm">
            <ul>
                <li>
                    <div class="s-one">
                        <p class="o-b">解决问题：机构什么动向？</p>
                        <p>现在行情买不买？</p>
                        <span>掌握市场活跃资金并进行大数据演算，</span><br/>
                        <span>为您揭示个股活跃资金机构动向，</span><br/>
                        <span>与强者共舞。并跟踪主力异动，</span><br/>
                        <span>判断买卖刚请及牛股资讯，</span><br/>
                        <span>及时把握大行情。</span>
                    </div>

                </li>
                <li>
                    <div class="s-two">
                        <p class="o-b">解决问题：重大利好在哪里？</p>
                        <p>这么多股票选哪个？</p>
                        <span>用热点题材及重大利好等。牛股池系统，</span><br/>
                        <span>如黑马雷达、主力强买、飞龙在天等，</span><br/>
                        <span>全面出击每日强势股，三分钟选出牛股票。</span>
                    </div>
                </li>
                <li>
                    <div class="s-three">
                        <p class="o-b">解决问题：什么时候买？</p>
                        <p>什么时候买？</p>
                        <span>配合主力增仓的资金动向，</span><br/>
                        <span>根据操盘线"B点买、S点卖"原则，</span><br/>
                        <span>当操盘线发出B点买入信号，</span><br/>
                        <span>提示是较好的介入时机，可有效吃涨幅。</span>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="c-three">
        <ul>
            <li>
                <p>PDI线从下向上突破MDI线</p>
                <p class="t-b">显示有新多头进场，为买进信号；</p>
                <p>PDI线从上向下跌破MDI线</p>
                <p class="t-b">显示有新空头进场，为卖出信号</p>
            </li>
            <li>
                <p>可统计个性化选定的股票在任意</p>
                <p>时段内的累计涨跌幅、换手率、</p>
                <p>最大涨幅等项目进行排名和比较，</p>
                <p class="t-b">帮助发现主力动向以及挑选潜力股；</p>
            </li>
            <li>
                <p>PDI线从下向上突破MDI线，</p>
                <p class="t-b">显示有新多头进场，为买进信号；</p>
                <p>PDI线从上到下跌破MDI线，</p>
                <p class="t-b">显示有新空头进场，为卖出信号；</p>
            </li>
        </ul>
    </div>
    <div class="last">
        <div class="l-q down">立即下载</div>
    </div>
</div>

<div class="copyright">
    <h2 style="margin-bottom: 0;">投资有风险,入市需谨慎</h2>
    <p>&copy; 版权所有：韩城集升商贸有限公司  ICP备案号：粤ICP备16126816号-1</p>
</div>
{{--写跳转过来的页面--}}
<input type="hidden" name="referr" value="<?= isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] :'' ?>">
<!--遮罩层-->
<div class="layui-layer-shade" id="layui-layer-shade3" time="3" style="display:none;"></div>
<!--表单-->
<div class="layui-layer layui-layer-page layer-form layer-anim" id="layui-layer3" type="page" showtime="0"time="3" contype="object" style="display: none;left:12rem;top:24rem;">
    <div id="" class="layui-layer-content">
        <div class="modal-form layui-layer-wrap" id="modal-form" style="display: block;">
            <p style="font-size: 40px;color:#41A5DD ;text-align: center;padding-top: 40px;">免费下载</p>
            <p style="font-weight:normal; color:#999; font-family:宋体; font-size:14px;text-align: center;padding-top:10px;">（请正确填写手机号码，以便获取软件账号和密码！）</p>
            <form id="form-1" class="validate nice-validator n-default" action="index1.html#" method="post" novalidate="novalidate">

                <input type="hidden" name="_token" value="{{csrf_token()}}" id="_token">
                <div class="form-content">
                    <div class="form-group">
                        <label for="txtName1" class="form-label">姓&nbsp;&nbsp;&nbsp;&nbsp;名</label>
                        <div class="form-input">
                            <input type="text" name="txtName1" id="txtName1" aria-required="true">
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="form-group">
                        <label for="txtPhone1" class="form-label">手机号</label>
                        <div class="form-input">
                            <input type="text" name="txtPhone1" id="txtPhone1" placeholder="" aria-required="true">
                        </div>
                        <div class="clear"></div>
                    </div>



                    <div class="form-group">
                        <label for="txtSmsCode1" class="form-label">验证码</label>
                        <div class="form-input">
                            <input type="text" name="txtSmsCode1" id="txtSmsCode1" class="input-vcode" maxlength="6">

                            <button id="btnYzm1" class="dz_yzm" value="免费获取验证码" onclick="javascript:return false;">
                                <span id="SendTxt1">免费获取验证码 </span>
                            </button>
                        </div>
                        <div class="clear"></div>
                    </div>

                    <div class="form-group" style="height: 70px">
                        <span class="form-group_button " id="btn-submit" type="button" onclick="">立即下载</span>

                    </div>
                    <div class="form-footer-text">
                        <p>我们采用加密技术确保您的信息安全，您的联系信息仅用于发送技术指标，请放心提交</p>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <span class="layui-layer-setwin"><a class="layui-layer-ico layui-layer-close layui-layer-close2" href="javascript:void (0);"></a></span>
    <span class="layui-layer-resize"></span>
</div>
{{--搜狗cnzz统计--}}
<script src="https://s19.cnzz.com/z_stat.php?id=1267444851&web_id=1267444851" language="JavaScript"></script>
</body>
<script>
    $(function (doc, win) {
        var docEl = doc.documentElement,
            resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
            recalc = function () {
                var clientWidth = docEl.clientWidth;
                if (!clientWidth) return;
                if (clientWidth >= 640) {
                    docEl.style.fontSize = '100px';
                } else {
                    docEl.style.fontSize = 100 * (clientWidth / 640) + 'px';
                }
            };

        if (!doc.addEventListener) return;
        win.addEventListener(resizeEvt, recalc, false);
        doc.addEventListener('DOMContentLoaded', recalc, false);
    });
</script>
<script>
    //获取所有的点击li标签，出现表单
    var Btns = $('.down');
    //获取遮罩层和表单元素
    var mask = $('#layui-layer-shade3');
    var Form = $('#layui-layer3');
    $(Btns).click(function()
    {
        $(mask).css('display','block');
        $(Form).css('display','block');
    });
</script>
<script src="{{url('js/form.js')}}"></script>
</html>