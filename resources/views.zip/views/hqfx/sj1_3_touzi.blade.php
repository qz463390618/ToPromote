<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>智能行情分析系统</title>
    <link rel="stylesheet" href="{{url('css/touzi/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{url('css/share.css')}}">
    <link rel="stylesheet" href="{{url('css/sj_form.css')}}">
    <link rel="stylesheet" href="{{url('css/touzi/n_sj_touzi.css')}}">
    <script src="{{url('js/jquery.js')}}"></script>
</head>
<body>
<div class="div-1">
    <div class="div-img">
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_1.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_2.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_3.png" alt=""></a>
    </div>
</div>
<div class="div-2">
    <img class="div-2-0" src="http://img.zengwf.com/images/ntouzi/img0.jpg" alt="">
    <div class="d-2-p">
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img1.jpg" alt="">
            <span>多周期交易神器</span>
            <p>从1分钟线到月线，都能适用绝不会放过每笔盈利机会</p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img2.jpg" alt="">
            <span>捕捉最有价值点位</span>
            <p>在行情启动瞬间准确预判对于机会把握的准确性大大提升</p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img3.jpg" alt="">
            <span>护盘线更智能</span>
            <p>行情接近尾声时，率先止盈出局防止盘面回落侵蚀利润</p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img4.jpg" alt="">
            <span>震荡行情独家法宝</span>
            <p>盈利机会可达5倍以上</p>
        </div>
    </div>
    <div class="div-img">
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_1.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_2.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_3.png" alt=""></a>
    </div>
</div>
<div class="div-3">
    <div class="d-2-p d-3-p">
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img5.png" alt="">
            <span>数据挖掘分析</span>
            <p>
                实时智能计算分析技术
                32687份分析报告
                113位高级金融工程师
                58位顶尖分析师研究团队
            </p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img6.png" alt="">
            <span>数据准确率</span>
            <p>
                交易数据对比指标
                贵金属ETF量化模型
                数十家金融投资机构测试
            </p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img7.png" alt="">
            <span>数据涨跌趋势</span>
            <p>
                市场情绪分析模型
                时间隧道计算技术
                贵金属趋势预判公
            </p>
        </div>
        <div>
            <img src="http://img.zengwf.com/images/ntouzi/img8.png" alt="">
            <span>明确买卖点提示</span>
            <p>
                多空力度对比模型
                技术参数计算模型
            </p>
        </div>
    </div>
    <div class="div-img">
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_1.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_2.png" alt=""></a>
        <a href="javascript:void(0)"><img src="http://img.zengwf.com/images/ntouzi/btn_3.png" alt=""></a>
    </div>
</div>
<div class="copyright">
    <h2 style="margin-bottom: 0;">投资有风险,入市需谨慎</h2>
    <p>&copy; 版权所有：北京中资北方投资顾问有限公司广州分公司  ICP备案号：粤ICP备16126816号-1</p>
</div>
{{--写跳转过来的页面--}}
<input type="hidden" name="referr" value="<?= isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] :'' ?>">
<!--遮罩层-->
<div class="layui-layer-shade" id="layui-layer-shade3" time="3" style="display:none;"></div>
<!--表单-->
<div class="layui-layer layui-layer-page layer-form layer-anim" id="layui-layer3" type="page" showtime="0"time="3" contype="object" style="display: none;left:16rem;top:24rem">
    <div id="" class="layui-layer-content">
        <div class="modal-form layui-layer-wrap" id="modal-form" style="display: block;">
            <p style="font-size: 40px;color:#41A5DD ;text-align: center;padding-top: 40px;">免费下载</p>
            <p style="font-weight:normal; color:#999; font-family:宋体; font-size:14px;text-align: center;padding-top:10px;">（请正确填写手机号码，以便获取软件账号和密码！）</p>
            <form id="form-1" class="validate nice-validator n-default" action="index1.html#" method="post" novalidate="novalidate">

                <input type="hidden" name="_token" value="{{csrf_token()}}" id="_token">
                <div class="form-content">
                    <div class="form-group">
                        <label for="txtName1" class="form-label">姓&nbsp;&nbsp;&nbsp;&nbsp;名</label>
                        <div class="form-input">
                            <input type="text" name="txtName1" id="txtName1" aria-required="true">
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="form-group">
                        <label for="txtPhone1" class="form-label">手机号</label>
                        <div class="form-input">
                            <input type="text" name="txtPhone1" id="txtPhone1" placeholder="" aria-required="true">
                        </div>
                        <div class="clear"></div>
                    </div>



                    <div class="form-group">
                        <label for="txtSmsCode1" class="form-label">验证码</label>
                        <div class="form-input">
                            <input type="text" name="txtSmsCode1" id="txtSmsCode1" class="input-vcode" maxlength="6">

                            <button id="btnYzm1" class="dz_yzm" value="免费获取验证码" onclick="javascript:return false;">
                                <span id="SendTxt1">免费获取验证码 </span>
                            </button>
                        </div>
                        <div class="clear"></div>
                    </div>

                    <div class="form-group" style="height: 70px">
                        <span class="form-group_button " id="btn-submit" type="button" onclick="">立即下载</span>

                    </div>
                    <div class="form-footer-text">
                        <p>我们采用加密技术确保您的信息安全，您的联系信息仅用于发送技术指标，请放心提交</p>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <span class="layui-layer-setwin"><a class="layui-layer-ico layui-layer-close layui-layer-close2" href="javascript:void (0);"></a></span>
    <span class="layui-layer-resize"></span>
</div>
{{--360cnzz统计数据引入--}}
<script src="https://s13.cnzz.com/z_stat.php?id=1267431564&web_id=1267431564" language="JavaScript"></script>
</body>
<script>
    //获取所有的点击li标签，出现表单
    var Btns = $('.div-img a');
    //获取遮罩层和表单元素
    var mask = $('#layui-layer-shade3');
    var Form = $('#layui-layer3');
    $(Btns).click(function()
    {
        $(mask).css('display','block');
        $(Form).css('display','block');
    });
</script>
<script src="{{url('js/form.js')}}"></script>
</html>